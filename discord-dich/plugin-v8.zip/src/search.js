load("config.js");

function execute(key, page) {
  var json = bridgeJson("/api/search", { key: key || "" });
  if (!json.ok) return Response.error(json.error || "Bridge error");
  return Response.success(toNovelList(json.data || []), json.next || null);
}
